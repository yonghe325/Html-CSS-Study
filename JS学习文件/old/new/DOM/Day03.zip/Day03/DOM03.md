# DOM03

## 回顾

DOM: `D`ocument `O`bject `M`odel -- `文档对象模型`

- `HTML CSS JS` ---> `document`对象  ---> 解析到浏览器展示
- 浏览器真正展示的是 doucment 对象的内容
- 作用: 直接用JS来操作document, 影响浏览器的展示 -- 更加灵活



学习DOM的核心操作分两类

- 如何查找到元素
  - 选择器
    - querySelector : 单个元素
    - querySelectorAll : 多个元素
  - 关系
    - 父
    - 子 : children,  通常搭配 数组解构 语法
    - 兄 : previousElementSibling
    - 弟 : nextElementSibling
  - 特征
    - id : getElementById
- 元素的属性
  - 样式
    - class : 固定样式的切换
      - className : 样式类的本体
      - classList : 集合了很多 操作样式类的方法
    - style : 内联样式, 适合动态设定
    - getComputedStyle :获取元素当前的所有样式信息 
  - 事件: 都是 on 开头的属性, 会在特定事件发生时触发
    - onclick : 点击时
    - onmouseover : 鼠标悬浮在上方
  - 图片的src : 可以指定图片上显示的内容
  - 自定义属性
    - 非规范: 随意书写的名称
      - getAttribute : 获取属性名
      - setAttribute : 设置属性的值
    - 规范: `data-属性名`
      - 存储在 `dataset` 中, 属性名自动转小驼峰



## 购物车

```html
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>购物车 17:25</title>

  <link rel="stylesheet" href="reset.css">
  <style>
    table {
      border-collapse: collapse;
    }

    thead {
      background-color: #eee;
    }

    td,
    th {
      border: 1px solid gray;
      padding: 10px 20px;
    }
  </style>
</head>

<body>
  <table>
    <thead>
      <tr>
        <th>商品信息</th>
        <th>单价</th>
        <th>数量</th>
        <th>金额</th>
      </tr>
    </thead>

    <tbody>
      <tr>
        <td>iPhone14</td>
        <td>7999</td>
        <td>
          <button>-</button>
          <span>4</span>
          <button>+</button>
        </td>
        <td>???</td>
      </tr>

      <tr>
        <td>笔记本电脑</td>
        <td>9999</td>
        <td>
          <button>-</button>
          <span>1</span>
          <button>+</button>
        </td>
        <td>???</td>
      </tr>

      <tr>
        <td>大宝</td>
        <td>9.9</td>
        <td>
          <button>-</button>
          <span>2</span>
          <button>+</button>
        </td>
        <td>???</td>
      </tr>
    </tbody>

    <tfoot>
      <tr>
        <td colspan='4'>总和: ???</td>
      </tr>
    </tfoot>
  </table>

  <script>
    // 功能: 更新每一行的内容
    function update() {
      // 查询到每一行记录
      const rows = document.querySelectorAll('tbody>tr')
      // 总和
      const td_sum = document.querySelector('tfoot td')
      let sum = 0

      rows.forEach(row => {
        const [, td_price, td_counter, td_total] = row.children
        const [btn_jian, span_num] = td_counter.children
        // 总金额 = 单价 x 数量
        td_total.innerHTML = (td_price.innerHTML * span_num.innerHTML).toFixed(2)

        sum -= -td_total.innerHTML

        // 减按钮的不可用状态, 数量==1 则不可用为真; 比较运算符的结果本身就是boolean
        btn_jian.disabled = (span_num.innerHTML == 1)
      })

      td_sum.innerHTML = `总和: ${sum}`
    }

    update()

    /////////////////////////////////////
    // 找到所有的计数器, 挨个添加相关事件
    const counters = document.querySelectorAll('tbody>tr>td:nth-child(3)')

    counters.forEach(counter => {
      const [btn1, span, btn2] = counter.children

      btn2.onclick = function () {
        span.innerHTML++
        update() //更新
      }

      btn1.onclick = function () {
        span.innerHTML--
        update()
      }
    })
  </script>
</body>

</html>
```



## 表单事件

```html
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>表单元素的事件 09:21</title>
</head>

<body>
  <!-- form表单: 用于收集用户数据 -->
  <input type="text">
  <br>
  <input type="range">
  <br>
  <input type="checkbox">
  <br>
  <input type="radio">
  <br>
  <select>
    <option value="0">雅迪</option>
    <option value="1">小牛</option>
  </select>

  <script>
    const inp = document.querySelector('input[type=text]')

    // 获得焦点
    inp.onfocus = function () {
      console.log('获得焦点')
    }

    // 失去焦点
    inp.onblur = function () {
      console.log('失去焦点');
    }

    // 内容变更: 回车 或 失去焦点时, 检测到内容变化
    inp.onchange = function () {
      // value: 存储输入框的值
      console.log('change:', this.value)
    }

    // 内容实时变更
    inp.oninput = function () {
      console.log('input:', this.value);
    }

    // 键盘事件
    // keyup: 按键抬起
    // 事件参数: 系统事件触发时, 会自动把 此次事件的所有相关信息 作为参数传递给函数
    inp.onkeyup = function (e) {
      // 形参名随意, 要求: 见名知意;  事件的英文:event, 习惯简写成e
      console.log('keyup:', e)
      // 回车编号13, 利用编号判断触发事件的按键
      if (e.keyCode == 13) alert("回车操作!")
    }
  </script>
</body>

</html>
```



## 练习 -- 实时过滤

```html
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>练习 10:05</title>
</head>

<body>
  <input type="text" name="" id="">
  <ul id='box'></ul>

  <script>
    const url = 'https://api.xin88.top/game/heros.json'

    var xhr = new XMLHttpRequest()
    xhr.open('get', url)
    xhr.send()
    xhr.onload = function () {
      var data = JSON.parse(xhr.response)
      console.log(data)

      const inp = document.querySelector('input')
      inp.oninput = function () {
        console.log('搜索:', this.value)

        // 从请求到的值中, 过滤出包含搜索词的元素
        var result = data.hero.filter(value => {
          // 判断 关键词中, 是否包含搜索的文字;   不是-1 就代表存在
          return value.keywords.indexOf(this.value) != -1
        })

        console.log('result:', result)

        // 数组元素 转 li 标签, 放到box里
        const box = document.getElementById('box')
        box.innerHTML = result.map(value => {
          const { title, name } = value
          return `<li>${name} - ${title}</li>`
        }).join('')

        if (this.value == '') box.innerHTML = ''
      }
    }
  </script>
</body>

</html>
```



## 练习 - 输入验证

```html
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>练习 10:20</title>
  <style>
    /* + :兄弟选择器 */
    #phone+div {
      color: red;
      font-size: 12px;
      /* 通过透明度实现隐藏 */
      visibility: hidden;
    }

    input {
      outline: none;
      border: 1px solid gray;
      border-radius: 4px;
      padding: 5px;
    }

    #phone:focus {
      border-color: blue;
    }

    #phone.err {
      border-color: red;
    }

    #phone.err+div {
      visibility: visible;
    }
  </style>
</head>

<body>
  <!--  -->
  <input class='' maxlength='11' type="text" placeholder='请输入手机号' id='phone'>
  <div>手机号码格式不正确</div>

  <script>
    // 思路: 当输入框失去焦点时, 判断其中的值是否是合法的手机号
    const phone = document.getElementById('phone')
    // 失去焦点
    phone.onblur = function () {
      // 输入框为空, 则不需要检测
      if (this.value == '') return //终止运行

      // 字符串格式验证: RegExp - 正则表达式
      const reg = /^1[3-9]\d{9}$/

      if (reg.test(this.value)) {
        this.classList.remove('err')
      } else {
        this.classList.add('err')
      }
    }

    //////////////////////////
    // 鼠标进入时, 隐藏错误
    phone.onfocus = function () {
      this.classList.remove('err')
    }
  </script>
</body>

</html>
```



## 勾选框

```html
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>练习 11:11</title>
</head>

<body>
  <div id="box">
    <label>
      <input type="checkbox">
      我已阅读并同意用户注册协议
    </label>
  </div>

  <button disabled>提交注册</button>

  <script>
    const chb = document.querySelector('[type=checkbox]')
    const btn = document.querySelector('button')

    // 当有变更时:
    chb.onchange = function () {
      console.log('变更', this.checked)
      // 可以用: 不 不可用
      // 勾选为真, 则不可用 为假
      btn.disabled = !this.checked
    }
  </script>
</body>

</html>
```



## 冒泡

```html
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>冒泡 11:22</title>

  <style>
    #red {
      background-color: red;
      width: 500px;
      height: 500px;
    }

    #green {
      background-color: green;
      width: 400px;
      height: 400px;
    }

    #blue {
      background-color: blue;
      width: 300px;
      height: 300px;
    }
  </style>
</head>

<body>
  <!--  -->
  <div id="red">
    <div id="green">
      <div id="blue"></div>
    </div>
  </div>

  <script>
    // 事件冒泡: 子元素上触发事件时, 会触发父元素同样的事件

    // 触发事件的 `当事人` : 事件参数中的 target 属性 -- 存储的是当事元素
    red.onclick = function (e) {
      console.log('red click!')
      console.log('触发本次事件的当事元素:', e.target);
    }

    green.onclick = function (e) {
      console.log('green click!')
      console.log('触发本次事件的当事元素:', e.target);
    }

    blue.onclick = function (e) {
      console.log('blue click!')
      console.log('触发本次事件的当事元素:', e.target);
      // 停止冒泡: 父元素不会收到此次事件的通知
      // stop: 停止  propagation: 传播
      e.stopPropagation()
    }
  </script>
</body>

</html>
```



## 代理

```html
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>委托 11:37</title>

  <style>
    ul {
      display: flex;
      margin: 0;
      padding: 0;
      list-style: none;
      border: 1px solid gray;
    }

    li {
      padding: 10px 20px;
      background-color: #eee;
      margin: 5px;
    }

    .active {
      background-color: orange;
      color: white;
    }
  </style>
</head>

<body>
  <!-- 冒泡的应用场景: 委托 -->
  <!-- 自己的事情 让别人帮忙处理; 此处 - 子元素的事情, 让父元素帮忙处理 -->

  <ul>
    <li>泡泡</li>
    <li>铭铭</li>
    <li>亮亮</li>
    <li>小新</li>
    <li>凯凯</li>
  </ul>

  <script>
    // const lis = document.querySelectorAll('li')
    // 缺点: 需要为每个li 绑定单独的方法 -- 多余, 浪费内存
    // lis.forEach(li => li.onclick = function () {
    //   this.classList.add('active')
    // })

    const ul = document.querySelector('ul')

    ul.onclick = function (e) {
      console.log('ul click!')
      console.log('当事元素:', e.target)
      // 需要判断当事元素的特征, 过滤出你想要操作的
      console.dir(e.target) // 找一找 哪个属性能分辨出 li 元素?

      if (e.target.localName == 'li') {
        e.target.classList.add('active') // 为当事元素添加
      }
    }
  </script>
</body>

</html>
```



## 动态新增元素

```html
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>动态新增的子元素 14:05</title>
</head>

<body>
  <button>新增</button>

  <ul>
    <li>亮亮</li>
    <li>泡泡</li>
    <li>铭铭</li>
  </ul>

  <script>
    const btn = document.querySelector('button')
    const ul = document.querySelector('ul')

    btn.onclick = function () {
      ul.innerHTML += '<li>凯凯</li>'
    }

    //////////////////////////////
    // 为每个li 新增点击事件,  点击后 style.color='red'

    // 不适合新增的li
    // const lis = document.querySelectorAll('li')
    // lis.forEach(li => li.onclick = function () {
    //   this.style.color = 'red'
    // })

    // 委托模式:
    ul.onclick = function (e) {
      console.log('当时元素:', e.target);
      if (e.target.localName == 'li') {
        e.target.style.color = 'red'
      }
    }
  </script>
</body>

</html>
```

## 事件监听器

```html
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>事件监听器 14:24</title>
</head>

<body>
  <button>Click Me!</button>

  <script>
    const btn = document.querySelector('button')
    // onclick属性: 同一时间只能存储 1个函数
    // 而在开发中如果 给onclick 多次赋值, 最后1个会覆盖其他的, 生效
    // 团队合作: 不同的队员 给同一个元素 同一个事件 捆绑函数
    btn.onclick = function () {
      console.log(11)
    }

    // on: 当...时;  click: 事件名-点击
    // onclick : 当 点击 时
    btn.onclick = function () {
      console.log(22)
    }

    // 事件监听器: 可以给同一个元素的同一个事件 捆绑多个方法, 按照顺序触发
    // 参数1: 事件名 -- 没有前缀 on 
    // 参数2: 对应的方法
    btn.addEventListener('click', function () {
      console.log(33);
    })

    btn.addEventListener('click', function () {
      console.log(44);
    })

    /**
     * 取舍:
     * on : 书写简单 但是 存在被覆盖的风险
     * addEventListener: 书写复杂 没有被 覆盖的风险
    */
  </script>
</body>

</html>
```

## 滚动事件

```html
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>滚动事件 14:39</title>
  <style>
    #nav {
      padding: 20px;
      background-color: orange;
      position: fixed;
      top: 0;
      width: 100%;
      left: 0;
    }
  </style>
</head>

<body>
  <!-- 经常需要监听网页的滚动, 提供一些响应 -->
  <ul id='box'></ul>

  <div id="nav" style='display: none;'>
    <h1>我是导航栏...</h1>
    <button>回到顶部</button>
  </div>

  <script>
    const btn = document.querySelector('button')

    btn.addEventListener('click', function () {
      // 连续赋值的语法:  a = b = c = 5
      // 兼容问题: 由于浏览器的厂商众多, 版本也多
      // 新旧的浏览器中, 提供了不同的 设计偏移量的写法, 如下:
      // scrollTop: 用于设置 滚动操作 距离顶部的偏移量
      document.body.scrollTop = document.documentElement.scrollTop = 0
    })

    for (let i = 0; i < 1000; i++) {
      box.innerHTML += `<li>${i}</li>`
    }

    // 事件名: scroll
    // 不写前缀, 说明是 window.addEvent...  监听窗口的滚动
    addEventListener('scroll', function () {
      // pageYOffset: 滚动距离顶部的偏移量
      console.log('滚动...:', pageYOffset)

      // 如果滚动距离超过500 就显示导航栏
      if (pageYOffset > 500) {
        nav.style.display = '' //不写值, 则采用自带的默认值
      } else {
        nav.style.display = 'none'
      }
    })
  </script>
</body>

</html>
```

## 创建DOM元素

```html
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>创建DOM元素 15:20</title>
</head>

<body>
  <!-- 
    普通的网页制作方式
    HTML+CSS+JS -> document -> 渲染到页面
    浏览器负责把完成如上的转换操作, 
    HTML 和 CSS 转换成document 对象 == JS, 需要消耗 少量的计算机资源-CPU
    
    追求极致的性能: 可以选择帮浏览器完成 HTML 转 JS 的操作
    即: 直接书写JS的代码 来创建HTML 元素
   -->

  <script>
    //创建ul标签
    // createElement: 创建元素
    const ul = document.createElement('ul')

    const li = document.createElement('li')
    li.innerHTML = '凯凯'
    console.log(li)

    // 把li作为子元素, 存储到ul中
    ul.appendChild(li)  //append:添加   child:子元素

    console.log(ul)

    document.body.appendChild(ul)
  </script>
</body>

</html>
```

## jQuery仿写

![image-20221207153630197](assets/image-20221207153630197.png)

```html
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Query 15:31</title>
</head>

<body>
  <ul id='box'>
    <li>泡泡</li>
    <li>亮亮</li>
    <li>铭铭</li>
  </ul>

  <script>
    // 问题: 原生的DOM操作较为复杂
    // 1. 方法名过长  -- previousElemenSibling; document.querySelectorAll
    // 2. 经常要 forEach 遍历

    // 需求: 利用封装技巧, 简化代码, 希望写的少;  自带遍历 - 做的更多

    //用原生DOM来实现: 查询到所有li, 挨个设置 style.color = 'blue'
    // const lis = document.querySelectorAll('li')
    // lis.forEach(li => {
    //   li.style.color = 'blue'
    // })

    //////////////////////////////////////////////////////
    function $(s) {
      return document.querySelectorAll(s)
    }

    NodeList.prototype.css = function () {
      // 关键词this: css方法所在对象
      console.log('this:', this)
      // 遍历, 为每个元素设置style
      this.forEach(el => {
        // [变量] : 会替换成变量的值, 即 'color'

        // 函数重载: 如果收到两个实参, 则认为是 css(属性名, 值)
        if (arguments.length == 2) {
          const [name, value] = arguments
          el.style[name] = value
        }
        if (arguments.length == 1) {
          // 遍历参数对象
          for (const name in arguments[0]) {
            const value = arguments[0][name]
            el.style[name] = value
          }
        }
      })
    }

    console.log($('li'))

    // 利用封装技巧, 改造成:
    $('li').css('color', 'blue')
    // $('li').css('font-size', '20px')
    // $('li').css('margin', '5px')

    // 新需求
    $('li').css({
      'font-size': '20px',
      margin: '4px',
      border: '1px solid red'
    })
  </script>













  <script>
    // 对象属性操作的两种语法: 点语法  方括号语法
    var emp = { ename: "泡泡" }

    console.log(emp.ename) //点语法: 直接写属性名

    // 方括号语法:  [] 中是JS代码
    var n = 'ename'
    console.log(emp[n])

    console.log(emp['en' + 'ame']);
  </script>
</body>

</html>
```

```html
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Query 16:32</title>

  <style>
    .ok {
      background-color: green;
      color: white;
      padding: 10px;
      border-radius: 4px;
    }
  </style>
</head>

<body>
  <ul>
    <li>泡泡</li>
    <li>亮亮</li>
    <li>铭铭</li>
  </ul>

  <script>
    // 尝试封装, 实现如下效果:

    function $(s) {
      return document.querySelectorAll(s)
    }

    NodeList.prototype.addClass = function (name) {
      this.forEach(el => {
        el.classList.add(name)
      })
    }

    $('li').addClass('ok') //自动为 每个li 添加 class='ok'
  </script>
</body>

</html>
```

