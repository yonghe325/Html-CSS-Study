-- 简单查询：模糊条件查询
--  %  匹配任意个字符  >=0
--  _  匹配任意1个字符  =1
--  注意事项：以上两个匹配的符号必须结合like关键字使用。
-- 示例：查询出姓名中含有字母e的员工有哪些
 select * from emp where ename like '%e%';
-- 练习：查询出姓名中以e结尾的员工
 select * from emp where ename like '%e';
-- 练习：查询出姓名中倒数第2个字符是e的员工 
 select * from emp where ename like '%e_';

-- 二.复杂查询
-- 1.聚合查询/分组查询
-- 聚合函数：count()/sum()/avg()/max()/min()
--           数量    总和  平均   最大  最小
-- 示例：查询出所有员工的数量    
  select count(*) from emp; 
-- 练习：使用员工的编号列查询员工数量
  select count(eid) from emp;  -- 17
-- 练习：使用员工所属部门编号列查询员工数量
  select count(deptid) from emp;  -- 16
-- 练习：查询出20号部门的工资总和
  select sum(salary) from emp where deptid=20;
-- 练习：查询出所有女员工的平均工资	
  select avg(salary) from emp where sex=0; 
-- 练习：查询出男员工的最高工资
  select max(salary) from emp where sex=1;
-- 练习：查询出年龄最大的员工的生日
  select min(birthday) from emp;

-- 分组查询：通常只是用于查询聚合函数和分组条件。
-- group  by
-- 示例：查询出男女员工的数量、工资总和分别是多少
  select count(*),sum(salary),sex from emp group by sex;
-- 练习：分别查询出各部门员工的数量，最高工资，最低工资，平均工资。
  select count(*),max(salary),min(salary),avg(salary),deptid from emp group by deptid;

-- year() 获取日期中的年份部分
-- 示例：获取 日期 2022-11-3 年份
  select year('2022-11-3');
-- 练习：查询出所有员工出生的年份
  select year(birthday) from emp;
-- 练习：查询出1993年出生的员工有哪些
  select * from emp where year(birthday)=1993;

-- md5()  对一个值进行加密
  select md5('123456'); 
	
-- 2.子查询
-- 是多个查询命令的组合，把一个的查询结果作为另一个的条件来使用。
-- 示例：查询出工资最高的员工
-- 步骤1：查询出工资的最高值是多少 ———— 50000
  select max(salary) from emp;
-- 步骤2：通过工资最高值查询对应的员工
  select * from emp where salary=50000;
-- 综合： 
  select * from emp where salary=(select max(salary) from emp);
	
-- 练习：查询出比king工资高的员工有哪些	
-- 步骤1：查询出king的工资 ———— 10000
select salary from emp where ename='king';
-- 步骤2：查询高于工资值的员工
select * from emp where salary>10000;	
-- 综合：
select * from emp where salary>(select salary from emp where ename='king');

-- 练习：查询出和lucy同一个部门的员工有哪些
-- 步骤1：查询出lucy的部门编号 —— 20
  select deptid from emp where ename='lucy';
-- 步骤2：通过部门编号查询对应员工，排除lucy
  select * from emp where deptid=20 and ename!='lucy';
-- 综合：
  select * from emp where deptid=(select deptid from emp where ename='lucy') and ename!='lucy';
	
-- 练习：查询出和tom同一年出生的员工有哪些	
-- 步骤1：查询出tom出生的年份 —— 1990
  select year(birthday) from emp where ename='tom';
-- 步骤2：通过年份查询出对应的员工
  select * from emp where year(birthday)=1990 and ename!='tom';
-- 综合：
  select * from emp where year(birthday)=(select year(birthday) from emp where ename='tom') and ename!='tom';

-- 3.多表查询
-- 查询的列分布在多个表中，前提是表之间已经建立了关联
-- 示例：查询出所以员工的姓名及其部门名称
  select ename,dname from emp,dept where deptid=did;
  select emp.ename,dept.dname from emp,dept where emp.deptid=dept.did;

