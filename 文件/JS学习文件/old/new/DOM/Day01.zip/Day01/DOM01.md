# DOM01

> DOM: `D`ocument `O`bject `M`odel   - 文档对象模型
>
> - Document: 文档 -- HTML代码, 超链接文本标记语言
> - Object: JS的对象类型
> - Model: 模型, 文档转换成JS对象的设定

<img src="C:\Users\73690\AppData\Roaming\Typora\typora-user-images\image-20221205090622991.png" alt="image-20221205090622991" style="zoom:67%;" />

> 玩游戏时:
>
> - Q  -> `游戏检测到,根据当前角色,转换成技能` -> 回音波

<img src="assets/image-20221205093053210.png" alt="image-20221205093053210" style="zoom:67%;" />

## DOM树

当document对象的结构, 用图形的方式进行展现时, 样子类似一棵树

```html
<html>
  <head>
    <title>首页</title>
    <meta name="referrer" content="no-referrer" />
  </head>
  <body>
    <h1>你好</h1>
    <div>Hello</div>
    <ul>
      <li>泡泡</li>
      <li>亮亮</li>
    </ul>
  </body>
</html>
```

转换成 document 对象后:

```js
var document = {
  html:{
  	children:{
      head:{
        children:{
          title:{
            innerHTML:"首页"
          },
          meta:{
            name:"referrer",
            content: "no-referrer"
          }
        }
      },
      body:{
        children:{
          h1:{ 
            innerHTML: '你好'
          },
          div:{
            innerHTML:"Hello"
          },
          ul:{
            children:{
              li:{ innerHTML:"泡泡" },
              li:{ innerHTML:"亮亮" },
            }
          }
        }
      }
    }
	}
}
```

用图的方式来表示:

- 看起来像: `树根` 或 `倒着的树` -- 所以称为 `DOM树`
- 每个元素称为 一个`节点 - Node`

<img src="assets/image-20221205095533383.png" alt="image-20221205095533383" style="zoom:67%;" />



## DOM

```html
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>dom 09:10</title>
  <style>
    #time {
      color: white;
      font-size: 25px;
      padding: 20px;
      background-color: #076bc1;
      border-radius: 10px;
      width: 300px;
    }
  </style>
</head>

<body>
  <div id="time"></div>

  <script>
    // 获取当前时间: 需要 JS 的 Date
    var d = new Date()
    // 转换为 当地的时间格式
    console.log(d.toLocaleTimeString())

    // 这就属于DOM操作: 用JS代码来操作HTML的内容
    time.innerHTML = d.toLocaleTimeString()

    //
    console.log(window) //检查其中的 document 属性
    // window.document : 全局中的属性, 使用时可以省略前缀 window
    console.log(document) // 美颜后的
    console.dir(document) // 真正的对象

    // document: 是JS对象
    // - 是HTML 被浏览器执行后, 转换而来的对象
    // - 浏览器后台的元素标签, 就是 document 对象转换成HTML标签的样式
    // - 浏览器中真正展示的内容, 就是document 对象

    // 学习DOM: 就可以直接通过 document 来操作网页


    document.title = "Hello DOM!"

    // 每秒变一次  1000毫秒 == 1秒
    setInterval(() => {
      var t = new Date().toLocaleTimeString()

      document.title = t

      time.innerHTML = t
    }, 1000);
  </script>
</body>

</html>
```



## class操作

```html
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>class 10:15</title>
  <link rel="stylesheet" href="reset.css">
  <style>
    ul {
      display: flex;
    }

    li {
      margin: 20px;
      /* 指针: 手 */
      cursor: pointer;
    }

    li:hover {
      color: coral;
    }

    /* 多个选择器连着书写: 代表同时具备这些特征 */
    /* <li class=jihuo */
    li.jihuo {
      font-weight: bold;
      color: coral;
      font-size: 18px;
    }
  </style>
</head>

<body>
  <!-- class: css中的, 可以批量设置样式 -->
  <ul>
    <li class='jihuo'>网游竞技</li>
    <li>单机热游</li>
    <li>手游休闲</li>
    <li>FPS射击</li>
    <li>卡牌棋牌</li>
  </ul>

  <script>
    // 需求: 点击li, 添加class='jihuo'

    // 思路: 找到所有的li标签
    // 在JS中如何找到 document 中的标签?

    // document提供了 querySelectorAll, 可以利用 css选择器找到你想要的元素
    // query: 查询
    // selector : 选择器
    // all : 所有,全部
    // 查询出 满足选择器的 全部元素
    // 参数: css选择器
    const lis = document.querySelectorAll('li')
    // 查询结果, 是 伪数组 类型, 原型是 NodeList.prototype
    // 其中也存在 forEach 方法可以使用 -- 从数组借来的
    console.log(lis)
    // 高阶函数: forEach 快速遍历数组
    lis.forEach(li => {
      console.log(li) // log: 美化后的
      console.dir(li) // 看本质, 支持展开查看
      // 有一类属性,都是 on 开头的, 称为事件;  事件文档如下:
      // https://www.runoob.com/jsref/dom-obj-event.html

      // onclick: 当鼠标点击DOM元素时触发的
      li.onclick = function () {
        console.log(this, '被点击')
        // 把被点击的DOM元素的 class='jihuo'

        // className: 就是class属性, 由于class在JS中是关键词, 所以被迫改名
        this.className = 'jihuo'
      }
    })
  </script>
</body>

</html>
```



## classList

```html
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>练习 11:27</title>
  <link rel="stylesheet" href="reset.css">
  <style>
    ul {
      display: flex;
    }

    li {
      margin: 5px;
      padding: 10px;
      cursor: pointer;
      background-color: #eee;
      border-radius: 5px;
    }

    li.active {
      background-color: orange;
      color: white;
    }
  </style>
</head>

<body>
  <h2>请选择你喜欢的球队</h2>
  <ul>
    <li>法国</li>
    <li>阿根廷</li>
    <li>中国队</li>
    <li>卡塔尔</li>
    <li>德国</li>
  </ul>

  <script>
    // 操作DOM的方式: 
    // 1. 先从 document 中找到你想操作的元素
    const lis = document.querySelectorAll('li')
    lis.forEach(li => {
      console.dir(li) //展开查看 classList 属性

      li.onclick = function () {
        // 通过判断来实现 切换效果
        // 这种切换操作使用场景很多, 但是代码比较繁琐
        // 作者帮你把一些常见的操作 封装在一起, 存储在 classList 属性中

        // toggle: 切换样式
        this.classList.toggle('active')

        // if (this.className == '') {
        //   this.className = 'active'
        // } else {
        //   this.className = ''
        // }
      }
    })

    // 2. 具体操作

  </script>
</body>

</html>
```



## 练习

```html
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>练习 11:56</title>
  <link rel="stylesheet" href="reset.css">
  <style>
    li {
      background-color: #eee;
      padding: 10px;
      width: 100px;
      border-radius: 5px;
      margin: 3px;
      cursor: pointer;
      transition: 0.3s;
    }

    li.active {
      width: 150px;
      background-color: orange;
    }
  </style>
</head>

<body>
  <ul>
    <li>亮亮</li>
    <li>泡泡</li>
    <li>铭铭</li>
  </ul>
</body>

</html>
```



## 菜单折叠

```html
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>菜单折叠效果 14:07</title>
  <style>
    .hide {
      display: none;
    }
  </style>
</head>

<body>
  <!-- 技巧: 在制作带有 隐藏 显示效果切换的场景中, 应该把HTML中应该显示的所有内容进行书写 -->
  <div id="box">
    <h2>HTML介绍</h2>
    <ul class='hide'>
      <li>HTML概述</li>
      <li>开始学习HTML</li>
      <li>head标签里面有什么?</li>
      <li>HTML文本基础</li>
    </ul>
  </div>

  <script>
    // 1. 为 h2 标签添加 点击事件
    // -- 先找到h2标签
    // querySelectorAll : 查找所有, 超过1个 的元素, 返回值 伪数组
    // querySelector : 查找单个元素, 仅限1个, 返回值 就是元素本身
    // 亮亮去超市买苹果:  买1个-拿着走 和 买好多个--装袋拿走
    const h2 = document.querySelector('#box>h2')
    console.log(h2)
    // 单个元素, 不需要遍历, 直接用
    h2.onclick = function () {
      console.log('h2被点击');
      // 查找元素的 弟弟元素
      // next:下一个 element:元素  sibling:邻居,兄弟
      const ul = this.nextElementSibling
      ul.classList.toggle('hide')
    }
  </script>
</body>

</html>
```

练习

```html
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>练习 14:30</title>

  <style>
    .hide {
      display: none;
    }
  </style>
</head>

<body>
  <div id="box">
    <h2>泡泡</h2>
    <ul class='hide'>
      <li>HTML</li>
      <li>CSS</li>
      <li>JS</li>
    </ul>

    <h2>亮亮</h2>
    <ul class='hide'>
      <li>吃饭</li>
      <li>睡觉</li>
      <li>打铭铭</li>
    </ul>
  </div>

  <script>
    // 要查找的元素个数 > 1
    const h2s = document.querySelectorAll('#box>h2') //伪数组

    h2s.forEach(h2 => {
      h2.onclick = function () {
        // 下一个兄弟元素
        this.nextElementSibling.classList.toggle('hide')
      }
    })
  </script>
</body>

</html>
```

## 唯一激活

```html
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>练习 15:05</title>
  <link rel="stylesheet" href="reset.css">
  <style>
    ul {
      display: flex;
    }

    li {
      margin-right: 10px;
    }

    img {
      width: 150px;
      height: 150px;
      /* 适配方式: 适合图片标签, 一旦图片的显示比例 和 实际比例不正确 的表现方式 */
      /* cover: 保持原有比例 */
      object-fit: cover;
      border-radius: 10px;
      transition: 0.5s;
    }

    img.active {
      width: 320px;
    }
  </style>
</head>

<body>
  <ul>
    <li><img class='active' src="./imgs/bigskin-1.jpg" alt=""></li>
    <li><img src="./imgs/bigskin-2.jpg" alt=""></li>
    <li><img src="./imgs/bigskin-3.jpg" alt=""></li>
    <li><img src="./imgs/bigskin-4.jpg" alt=""></li>
    <li><img src="./imgs/bigskin-5.jpg" alt=""></li>
  </ul>

  <script>
    const imgs = document.querySelectorAll('ul img')

    imgs.forEach(img => {
      img.onclick = function () {
        // 唯一性激活: 先查找到之前激活的 -- 逻辑上确定及肯定  有且只有一个
        const ac = document.querySelector('ul img.active')
        ac.classList.remove('active') // remove:删除样式

        // this.classList.toggle('active') //切换
        // 添加
        this.classList.add('active')
      }
    })
  </script>
</body>

</html>
```

练习

```html
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>练习 15:39</title>
  <link rel="stylesheet" href="reset.css">
  <style>
    img {
      width: 250px;
      height: 80px;
      border-radius: 5px;
      object-fit: cover;
      transition: 0.4s;
    }

    img.active {
      height: 150px;
    }

    li {
      margin-bottom: 5px;
    }
  </style>
</head>

<body>
  <ul>
    <li><img class='active' src="./imgs/bigskin-1.jpg" alt=""></li>
    <li><img src="./imgs/bigskin-2.jpg" alt=""></li>
    <li><img src="./imgs/bigskin-3.jpg" alt=""></li>
    <li><img src="./imgs/bigskin-4.jpg" alt=""></li>
    <li><img src="./imgs/bigskin-5.jpg" alt=""></li>
  </ul>

  <script>
    const imgs = document.querySelectorAll('ul img')

    imgs.forEach(img => {
      img.onclick = function () {
        // 找到之前激活的元素, 删除其 active 类
        const ac = document.querySelector('ul img.active')
        ac.classList.remove('active')

        this.classList.add('active')
      }
    })
  </script>
</body>

</html>
```

## 内联样式

```html
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>style 16:13</title>
  <!-- 内部样式 -->
  <style>
    /* 选择器方式 */
    p {
      color: olive;
    }
  </style>
</head>

<body>
  <!-- style: 内联样式, 直接在元素上书写的 style 属性 -->
  <!-- 优先级最高, 如果同时书写 class 和 style, 同样的样式, style优先生效 -->
  <button>变大</button>

  <p style='color: blue;'>Hello!</p>

  <script>
    // 需求: 点击按钮, 让p标签的文字变大
    // -- 这种需求 class 无法实现, 只适合固定的样式类

    const btn = document.querySelector('button') // 1个
    const p = document.querySelector('p')

    btn.onclick = function () {
      // 期望: 在p标签原本的字体大小 + 1
      // 获取某个元素的当前样式信息: getComputedStyle
      const info = getComputedStyle(p)
      console.log(info) // 查看字体大小在哪个属性?
      // 当前字体大小
      const fontSize = parseInt(info.fontSize) // '16px' -> 16

      // 修改 p 标签的内联样式
      console.dir(p) // 查看其style 内联样式属性

      p.style.fontSize = fontSize + 1 + 'px'
    }
  </script>
</body>

</html>
```

练习

```html
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>练习 16:33</title>
</head>

<body>
  <button>变大</button>
  <div id="box" style='background-color: gray; width: 50px; height: 50px;'></div>

  <script>
    const btn = document.querySelector('button')
    const box = document.querySelector('#box')

    btn.onclick = function () {
      // 解构语法, 可以从对象中快速读取属性 -- 上周五 12.02
      let { width, height } = getComputedStyle(box)

      width = parseInt(width) // '50px' -> 50
      height = parseInt(height)

      box.style.width = width + 2 + 'px'
      box.style.height = height + 2 + 'px'
    }
  </script>
</body>

</html>
```

```html
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>练习 16:51</title>
  <style>
    #box {
      width: 100px;
      height: 50px;
      background-color: gray;
      /* 相对定位: 相对在文档流中的位置进行调整 */
      position: relative;
      top: 0;
      left: 0;
      transition: 0.3s;
    }
  </style>
</head>

<body>
  <button>移动</button>
  <div id='box'></div>

  <script>
    const btn = document.querySelector('button')
    const box = document.querySelector('#box')

    btn.onclick = function () {
      let { left } = getComputedStyle(box)
      console.log(left)
      left = parseInt(left)

      box.style.left = left + 100 + 'px'
    }
  </script>
</body>

</html>
```

## 轮播图

```html
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>轮播图 17:22</title>

  <link rel="stylesheet" href="reset.css">
  <style>
    #banner {
      width: 600px;
      height: 300px;
      border: 2px solid red;
      /* 超出部分隐藏 */
      overflow: hidden;
      /* 定位: 子绝父相 */
      position: relative;
    }

    #banner>div {
      position: absolute;
      top: 50%;
      left: 0;
      transform: translateY(-50%);
      /* background-color: blue; */
      width: 100%;
      display: flex;
      justify-content: space-between;
    }

    #banner>ul {
      display: flex;
      width: 100%;
      height: 100%;
      /* 位移动画依赖这些: */
      position: relative;
      left: 0;
      top: 0;
      transition: 0.3s;
    }

    #banner>ul>li {
      min-width: 100%;
    }

    #banner>ul>li>img {
      width: 100%;
      height: 100%;
    }
  </style>
</head>

<body>
  <div id="banner">
    <ul>
      <li><img src="./imgs/bigskin-1.jpg" alt=""></li>
      <li><img src="./imgs/bigskin-2.jpg" alt=""></li>
      <li><img src="./imgs/bigskin-3.jpg" alt=""></li>
      <li><img src="./imgs/bigskin-4.jpg" alt=""></li>
      <li><img src="./imgs/bigskin-5.jpg" alt=""></li>
    </ul>
    <div>
      <button class='btn-prev'>上一个</button>
      <button class='btn-next'>下一个</button>
    </div>
  </div>

  <script>
    const banner = document.querySelector('#banner')
    const btn_next = document.querySelector('#banner .btn-next')
    const ul = document.querySelector('#banner ul')

    // 下一个
    btn_next.onclick = function () {
      let { left } = getComputedStyle(ul)
      left = parseInt(left)

      // 读取横幅的宽度
      let { width } = getComputedStyle(banner)
      width = parseInt(width)

      ul.style.left = left - width + 'px'
    }
  </script>
</body>

</html>
```



## 总结

DOM: Document Object Model - 文档对象模型

- HTML + CSS + JS: 运行时会被浏览器转换成 `document` 对象, 然后再展示到页面
- 而我们可以利用 JS 直接操作document对象, 来影响页面 -- `更加灵活`



DOM操作的知识点分两类

- 如何找到元素
  - 利用css选择器查找
    - querySelector: 查单个元素
    - querySelectorAll: 查多个元素
- 元素的具体属性
  - class
    - className : 样式类本身
    - classList : 一个集合, 存放了操作 class 的各种快捷方法
  - style: 内联样式
  - getComputedStyle : 获取某个元素的当前样式信息

## 作业

- 把遗留的`上一个` 做完
- 提前预习: 到FTP下载上个班级的笔记查看















